// MyTreeView.cpp : implementation file

#include "stdafx.h"
#include "SDIViewSwitch.h"
#include "MyTreeView.h"
#include "MySplitterWnd.h"
#include "FormView1.h"
#include "FormView2.h"
#include "MyEditView.h"
#include "MyListView.h"
#include "SplitterView.h" 
#include "RightPaneHorizSplitterView.h"
#include "RightPaneVertSplitterView.h"
#include "NoFormViewInRightPaneHorizSplitterView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CMyTreeView, CTreeView)

CMyTreeView::CMyTreeView()
{
	m_pTreeCtrl = NULL;
	//m_dwDefaultStyle is a documented member of CCtrlView
	m_dwDefaultStyle =  WS_CHILD | WS_VISIBLE | TVS_HASLINES  
			 | TVS_LINESATROOT | TVS_HASBUTTONS | TVS_SHOWSELALWAYS;   
}
/////////////////////////////////////////////////////////////////////////////
CMyTreeView::~CMyTreeView()
{
	TRACE("destructing CMyTreeView\n");	
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CMyTreeView, CTreeView)
	//{{AFX_MSG_MAP(CMyTreeView)
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelchanged)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	//ON_COMMAND(ID_ADD_FORM_VIEW, OnAddFormView)
	//ON_COMMAND(ID_REMOVE_FORM_VIEW, OnRemoveFormView)
	//ON_UPDATE_COMMAND_UI(ID_ADD_FORM_VIEW, OnUpdateAddFormView)
	//ON_UPDATE_COMMAND_UI(ID_REMOVE_FORM_VIEW, OnUpdateRemoveFormView)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
void CMyTreeView::OnDraw(CDC* pDC)
{
	// TODO: add draw code here
}
/////////////////////////////////////////////////////////////////////////////
// CMyTreeView diagnostics
#ifdef _DEBUG
void CMyTreeView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CMyTreeView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG
////////////////////////////////////////////////////////////////////////////////////
void CMyTreeView::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM hSelectedItem = m_pTreeCtrl->GetSelectedItem();
	if(hSelectedItem == m_hPreviousSelectedItem) //if same as last view, then don't need to ReplaceView
		return;

	m_hPreviousSelectedItem = hSelectedItem;

	CMySplitterWnd* pParentSplitter = (CMySplitterWnd*)GetParent();
	if(hSelectedItem == m_hRightPaneFormView1)
	{
		pParentSplitter->ReplaceView(RUNTIME_CLASS(CFormView1));
	}
	else if(hSelectedItem == m_hRightPaneFormView2)
	{
		pParentSplitter->ReplaceView(RUNTIME_CLASS(CFormView2));
	}
	else if(hSelectedItem == m_hRightPaneEditView)
	{
		pParentSplitter->ReplaceView(RUNTIME_CLASS(CMyEditView));
	}
	else if(hSelectedItem == m_hRightPaneListView)
	{
		pParentSplitter->ReplaceView(RUNTIME_CLASS(CMyListView));
	}
	else if(hSelectedItem == m_hRightPaneHorizSplitterView)
	{
		pParentSplitter->ReplaceView(RUNTIME_CLASS(CRightPaneHorizSplitterView));
	}
	else if(hSelectedItem == m_hRightPaneVertSplitterView)
	{
		pParentSplitter->ReplaceView(RUNTIME_CLASS(CRightPaneVertSplitterView));
	}

	*pResult = 0;
}
////////////////////////////////////////////////////////////////////////////////////
int CMyTreeView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_pTreeCtrl = &(GetTreeCtrl()); 

	HTREEITEM hTreeViews, hTreeBelow, hTreeMammals, hTreePlants, hTreeFish;
	hTreeViews = m_pTreeCtrl->InsertItem("* View Choices *", TVI_ROOT, TVI_SORT);
	m_hRightPaneFormView1        = m_pTreeCtrl->InsertItem("Form View 1"			, hTreeViews);
	m_hRightPaneFormView2        = m_pTreeCtrl->InsertItem("Form View 2"			, hTreeViews);
	m_hRightPaneEditView         = m_pTreeCtrl->InsertItem("Edit View"				, hTreeViews);
	m_hRightPaneListView         = m_pTreeCtrl->InsertItem("List View"              , hTreeViews);
	m_hRightPaneHorizSplitterView= m_pTreeCtrl->InsertItem("Horizontal SplitterView", hTreeViews);
	m_hRightPaneVertSplitterView = m_pTreeCtrl->InsertItem("Vertical SplitterView"  , hTreeViews);

	hTreeBelow   = m_pTreeCtrl->InsertItem("*Below items don't display views*", TVI_ROOT, TVI_SORT);

	hTreeMammals = m_pTreeCtrl->InsertItem("Mammals", hTreeBelow, TVI_SORT);
	hTreePlants  = m_pTreeCtrl->InsertItem("Plants" , hTreeBelow, TVI_SORT);
	hTreeFish    = m_pTreeCtrl->InsertItem("Fish"   , hTreeBelow, TVI_SORT);
	m_pTreeCtrl->InsertItem("Aardvark", hTreeMammals);
	m_pTreeCtrl->InsertItem("Baboon"  , hTreeMammals);
	m_pTreeCtrl->InsertItem("Cat"     , hTreeMammals);
	m_pTreeCtrl->InsertItem("Dog"     , hTreeMammals);
	m_pTreeCtrl->InsertItem("Birch", hTreePlants);
	m_pTreeCtrl->InsertItem("Elm"  , hTreePlants);
	m_pTreeCtrl->InsertItem("Maple", hTreePlants);
	m_pTreeCtrl->InsertItem("Oak"  , hTreePlants);
	m_pTreeCtrl->InsertItem("Bass"   , hTreeFish);
	m_pTreeCtrl->InsertItem("Cod"    , hTreeFish);
	m_pTreeCtrl->InsertItem("Grouper", hTreeFish);
	m_pTreeCtrl->InsertItem("Halibut", hTreeFish);

	m_pTreeCtrl->Expand(hTreeBelow  , TVE_EXPAND);   
	m_pTreeCtrl->Expand(hTreeViews  , TVE_EXPAND); 

	//Set background color of treeview. TVM_SETBKCOLOR requires Version 4.71 or newer of Comctl32.dll.
	//You can get an update to this DLL by installing the newest service pack for your OS.
	m_pTreeCtrl->SendMessage(TVM_SETBKCOLOR, 0, RGB(240,210,170)); // change the background color
	LONG style = ::GetWindowLong(m_pTreeCtrl->m_hWnd, GWL_STYLE);
	::SetWindowLong(m_pTreeCtrl->m_hWnd, GWL_STYLE, style & ~TVS_HASLINES);  // remove the style TVS_HASLINES
	::SetWindowLong(m_pTreeCtrl->m_hWnd, GWL_STYLE, style); //add the style back
		
	ShowWindow(SW_SHOW);
	UpdateWindow();	

	return 0;
}
/////////////////////////////////////////////////////////////////////////////
