// FormView1.cpp : implementation file

#include "stdafx.h"
#include "SDIViewSwitch.h"
#include "FormView1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CFormView1, CColorFormView)

CFormView1::CFormView1()
	: CColorFormView(CFormView1::IDD, RGB(20, 185, 220))  //gray-blue
{
	//{{AFX_DATA_INIT(CFormView1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CFormView1::~CFormView1()
{
	TRACE("destructing CFormView1\n");
}

void CFormView1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFormView1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFormView1, CColorFormView)
	//{{AFX_MSG_MAP(CFormView1)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFormView1 diagnostics
#ifdef _DEBUG
void CFormView1::AssertValid() const
{
	CFormView::AssertValid();
}

void CFormView1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
void CFormView1::OnButton1()
{
	TRACE("In CFormView1::OnButton1()\n");
}
