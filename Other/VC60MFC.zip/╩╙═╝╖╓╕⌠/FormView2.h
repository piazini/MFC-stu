#if !defined(AFX_FORMVIEW2_H__CB97F4D2_1752_11D2_B134_00C04FB9CA2B__INCLUDED_)
#define AFX_FORMVIEW2_H__CB97F4D2_1752_11D2_B134_00C04FB9CA2B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FormView2.h : header file
//
#include "ColorFormView.h"

/////////////////////////////////////////////////////////////////////////////
// CFormView2 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CFormView2 : public CColorFormView
{
protected:
	CFormView2();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFormView2)

// Form Data
public:
	//{{AFX_DATA(CFormView2)
	enum { IDD = IDD_FORMVIEW2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFormView2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFormView2();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CFormView2)
	afx_msg void OnCheck1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORMVIEW2_H__CB97F4D2_1752_11D2_B134_00C04FB9CA2B__INCLUDED_)
