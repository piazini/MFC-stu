#if !defined(AFX_MYLISTVIEW_H__15734491_4CEE_11D2_B149_00C04FB9CA2B__INCLUDED_)
#define AFX_MYLISTVIEW_H__15734491_4CEE_11D2_B149_00C04FB9CA2B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyListView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyListView view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include <afxcview.h>
#include "MyEditView.h"
#include "SDIViewSwitchDoc.h"

class CMyListView : public CListView
{
protected:
	CMyListView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMyListView)

// Attributes
public:
	bool m_bInitialized;
	UINT m_numberOfListViewColumns;

// Operations
public:
	void InitializeListView();
	void AddNewItem(UINT index, CSDIViewSwitchDoc* pDoc);
	void SetQuoteInEditView(UINT item);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyListView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMyListView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CMyListView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYLISTVIEW_H__15734491_4CEE_11D2_B149_00C04FB9CA2B__INCLUDED_)
