#if !defined(AFX_MYTREEVIEW_H__50_68_69_6C_69_70_20_4A_2E_20_53_70_6F_72_79_2E__INCLUDED_)
#define AFX_MYTREEVIEW_H__50_68_69_6C_69_70_20_4A_2E_20_53_70_6F_72_79_2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyTreeView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
#include <afxcview.h>

class CMyTreeView : public CTreeView
{
protected:
	CMyTreeView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMyTreeView)

// Attributes
public:
	CTreeCtrl* m_pTreeCtrl;
	HTREEITEM  m_hRightPaneFormView1;
	HTREEITEM  m_hRightPaneFormView2;
	HTREEITEM  m_hRightPaneEditView;
	HTREEITEM  m_hRightPaneListView;
	HTREEITEM  m_hRightPaneHorizSplitterView;
	HTREEITEM  m_hRightPaneVertSplitterView;
	HTREEITEM  m_hPreviousSelectedItem;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyTreeView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMyTreeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CMyTreeView)
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTREEVIEW_H__50_68_69_6C_69_70_20_4A_2E_20_53_70_6F_72_79_2E__INCLUDED_)
