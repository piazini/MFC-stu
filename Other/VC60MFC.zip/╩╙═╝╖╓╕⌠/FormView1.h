#if !defined(AFX_FORMVIEW1_H__CB97F4D1_1752_11D2_B134_00C04FB9CA2B__INCLUDED_)
#define AFX_FORMVIEW1_H__CB97F4D1_1752_11D2_B134_00C04FB9CA2B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FormView1.h : header file
//

#include "ColorFormView.h"

/////////////////////////////////////////////////////////////////////////////
// CFormView1 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CFormView1 : public CColorFormView
{
protected:
	CFormView1();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFormView1)

// Form Data
public:
	//{{AFX_DATA(CFormView1)
	enum { IDD = IDD_FORMVIEW1 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFormView1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFormView1();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CFormView1)
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORMVIEW1_H__CB97F4D1_1752_11D2_B134_00C04FB9CA2B__INCLUDED_)
