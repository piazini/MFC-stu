// RightPaneHorizSplitterView.cpp : implementation file

#include "stdafx.h"
#include "MainFrm.h"
#include "sdiviewswitch.h"
#include "RightPaneHorizSplitterView.h"
#include "FormView3.h"
#include "MyEditView.h"
#include "MyListView.h"
#include "MySplitterWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CRightPaneHorizSplitterView, CView)

CRightPaneHorizSplitterView::CRightPaneHorizSplitterView()
{
	m_bInitialized = false;
}
/////////////////////////////////////////////////////////////////////////////
CRightPaneHorizSplitterView::~CRightPaneHorizSplitterView()
{
	TRACE("destructing CRightPaneHorizSplitterView\n");	
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CRightPaneHorizSplitterView, CView)
	//{{AFX_MSG_MAP(CRightPaneHorizSplitterView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CRightPaneHorizSplitterView diagnostics
#ifdef _DEBUG
void CRightPaneHorizSplitterView::AssertValid() const
{
	CView::AssertValid();
}

void CRightPaneHorizSplitterView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
int CRightPaneHorizSplitterView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	//Create a splitter window with 3 panes all in one column (3 rows).
	//The 8 added to AFX_IDW_PANE_FIRST below is pretty arbitrary:
	m_WndRightPaneSplitter.CreateStatic(this, 3, 1, WS_CHILD|WS_VISIBLE, AFX_IDW_PANE_FIRST+8);
	CCreateContext *pContext = (CCreateContext*) lpCreateStruct->lpCreateParams;
	CSize size(0,0);
	m_WndRightPaneSplitter.CreateView(0,0, RUNTIME_CLASS(CFormView3 ), size, pContext);
	m_WndRightPaneSplitter.CreateView(1,0, RUNTIME_CLASS(CMyEditView), size, pContext);	
	m_WndRightPaneSplitter.CreateView(2,0, RUNTIME_CLASS(CMyListView), size, pContext);

	CMainFrame* pFrameWnd = (CMainFrame*)GetParentFrame();
	if(pFrameWnd == NULL || pFrameWnd->m_hWnd == NULL)
		ASSERT(0);
	pFrameWnd->m_bShowingFormView3InRightPaneHorizSplitter = true;

	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////
void CRightPaneHorizSplitterView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	//Increase size by 2 all around to remove hide border:
	m_WndRightPaneSplitter.MoveWindow(-2, -2, cx+2, cy+2);
	
	m_WndRightPaneSplitter.SetRowInfo(0, (2*cy)/5, 0); 
	m_WndRightPaneSplitter.SetRowInfo(1, cy/3, 0);
	m_WndRightPaneSplitter.SetRowInfo(2, cy/3, 0);
	m_WndRightPaneSplitter.RecalcLayout();  
}
////////////////////////////////////////////////////////////////////////////////////////////
void CRightPaneHorizSplitterView::OnInitialUpdate() 
{
	//Because of the structure of this app, when the frame is created, this function
	//is called more than once. The following flag insures the code after is only run once:
	if(m_bInitialized)
		return;
	m_bInitialized = true;

	for(int i = 0; i<3; i++) //3 views in this pane
	{
		CView* pView = (CView*)m_WndRightPaneSplitter.GetPane(i, 0);
		pView->OnInitialUpdate();
	}

	CMainFrame* pFrameWnd = ((CMainFrame*)AfxGetMainWnd());
	if(pFrameWnd == NULL || pFrameWnd->m_hWnd == NULL)
		return;
	pFrameWnd->m_bShowingFormView3InRightPaneHorizSplitter = true;
	pFrameWnd->AlterFrameForFormView3();	
}
////////////////////////////////////////////////////////////////////////////////////////////
void CRightPaneHorizSplitterView::OnDestroy() 
{
	CView::OnDestroy();
	
	CMainFrame* pFrameWnd = ((CMainFrame*)AfxGetMainWnd());
	if(pFrameWnd == NULL || pFrameWnd->m_hWnd == NULL)
		return;
	pFrameWnd->m_bShowingFormView3InRightPaneHorizSplitter = false;
	pFrameWnd->AlterFrameForFormView3(false);	
}
////////////////////////////////////////////////////////////////////////////////////////////
void CRightPaneHorizSplitterView::OnDraw(CDC* pDC) 
{
	// TODO: Add your specialized code here and/or call the base class
}
