// MyMenu.h: interface for the CMyMenu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYMENU_H__52F6C899_3A0B_4F17_B376_D83F9DE3A5E3__INCLUDED_)
#define AFX_MYMENU_H__52F6C899_3A0B_4F17_B376_D83F9DE3A5E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
class CMenuItemContext
{
public:
	CString lpszText;
	int nMenuID;
};
class CMyMenu : public CMenu  
{
public:
	CMyMenu();
	virtual ~CMyMenu();
	void AttachMenu(HMENU hMenu);
	void ChangeMenuStyle(HMENU hMenu);
	void SetBKColor(CDC *pDC,CRect rcItem);
	void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);

};

#endif // !defined(AFX_MYMENU_H__52F6C899_3A0B_4F17_B376_D83F9DE3A5E3__INCLUDED_)
