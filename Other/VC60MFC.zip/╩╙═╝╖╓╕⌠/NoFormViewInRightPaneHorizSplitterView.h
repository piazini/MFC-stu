#if !defined(AFX_NoFormViewInRightPaneHorizSplitterView_H__63A74B95_3B8E_11D2_B144_00C04FB9CA2B__INCLUDED_)
#define AFX_NoFormViewInRightPaneHorizSplitterView_H__63A74B95_3B8E_11D2_B144_00C04FB9CA2B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NoFormViewInRightPaneHorizSplitterView.h : header file

/////////////////////////////////////////////////////////////////////////////
class CNoFormViewInRightPaneHorizSplitterView : public CView
{
protected:
	CNoFormViewInRightPaneHorizSplitterView(); // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CNoFormViewInRightPaneHorizSplitterView)

// Attributes
public:
	bool m_bInitialized;
	CSplitterWnd m_WndRightPaneSplitter;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNoFormViewInRightPaneHorizSplitterView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CNoFormViewInRightPaneHorizSplitterView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CNoFormViewInRightPaneHorizSplitterView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NoFormViewInRightPaneHorizSplitterView_H__63A74B95_3B8E_11D2_B144_00C04FB9CA2B__INCLUDED_)
