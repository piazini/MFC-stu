// MyListView.cpp : implementation file
//

#include "stdafx.h"
#include "sdiviewswitch.h"
#include "MyListView.h"
#include "SDIViewSwitchDoc.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CMyListView, CListView)

CMyListView::CMyListView()
{
	m_numberOfListViewColumns = 5;
	m_bInitialized = false;
}
/////////////////////////////////////////////////////////////////////////////
CMyListView::~CMyListView()
{
	TRACE("destructing CMyListView\n");

	CMainFrame* pFrameWnd = ((CMainFrame*)AfxGetMainWnd());
	if(pFrameWnd)
		pFrameWnd->m_pListView = NULL;	
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CMyListView, CListView)
	//{{AFX_MSG_MAP(CMyListView)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
void CMyListView::OnDraw(CDC* pDC)
{
	// TODO: add draw code here
}
/////////////////////////////////////////////////////////////////////////////
// CMyListView diagnostics
#ifdef _DEBUG
void CMyListView::AssertValid() const
{
	CListView::AssertValid();
}

void CMyListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
void CMyListView::InitializeListView()
{
	CWaitCursor wc;
	CListCtrl& theListCtrl = GetListCtrl();
	theListCtrl.SetRedraw(FALSE); 
	
	//For the style LVS_EX_FULLROWSELECT, you'll need the following, depending on the OS:
	//Windows NT: Requires version 5.0 or later (or version 4.0 with Internet Explorer 3.0 and later).. 
	//Windows: Requires Windows 98 (or Windows 95 with Internet Explorer 3.0 or later). 
	//Otherwise, you'll need to do ownerdrawn stuff. In that case, see the MFC ROWLIST sample.
	DWORD dwExStyle = LVS_EX_FULLROWSELECT;

	theListCtrl.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, (WPARAM)dwExStyle, (LPARAM)dwExStyle);
	COLORREF crYellow = RGB(240,240,200); //light yellow
	theListCtrl.SetBkColor(crYellow);
	theListCtrl.SetTextBkColor(crYellow);

	theListCtrl.InsertColumn(0, "name");
	theListCtrl.InsertColumn(1, "address");
	theListCtrl.InsertColumn(2, "city");
	theListCtrl.InsertColumn(3, "state");
	theListCtrl.InsertColumn(4, "zip code");

	//The functions GetDocument() and GetParentFrame()->GetActiveDocument() won't always work 
	//here, so we will use the app's doc pointer:
	CSDIViewSwitchDoc* pDoc = ((CSDIViewSwitchApp*)AfxGetApp())->m_pDoc;

	//Read data from document:
	if(!pDoc->ReadHeader())
	{	//file doesn't have the proper signature
		AfxMessageBox("This is not a proper switchsplit file");
		return;
	}

	UINT numberOfRecords = pDoc->m_nNumberOfRecords;
	DOC_RECORD* pDocRecord = new DOC_RECORD;
	for(UINT index = 0; index < numberOfRecords; index++)
	{
		if(!pDoc->GetRecord(index, pDocRecord))
			theListCtrl.InsertItem(index, "data corruption");
		else
		{	
			//note: the data entries must be null terminated for this to work:
			theListCtrl.InsertItem(index, pDocRecord->name);
			theListCtrl.SetItemText(index, 1, pDocRecord->address);
			theListCtrl.SetItemText(index, 2, pDocRecord->city   );
			theListCtrl.SetItemText(index, 3, pDocRecord->state  );
			theListCtrl.SetItemText(index, 4, pDocRecord->zipcode);
		}
	}
	delete pDocRecord;

	for(UINT i = 0; i< m_numberOfListViewColumns; i++)
		theListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER); 

	//if any items in the list view, then take the quote from the first item
	if(theListCtrl.GetItemCount()) 
	{
		//Select the first item in the list view:
		theListCtrl.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED); 
		//and put it's corresponding quote in the editview (if an editview is visible):
		SetQuoteInEditView(0); 
	}

	theListCtrl.SetRedraw(TRUE);
	theListCtrl.Invalidate(); 
}
/////////////////////////////////////////////////////////////////////////////
void CMyListView::AddNewItem(UINT index, CSDIViewSwitchDoc* pDoc)
{
	CListCtrl& theListCtrl = GetListCtrl();
	DOC_RECORD* pDocRecord = new DOC_RECORD;
	theListCtrl.SetRedraw(FALSE); 	

	if(!pDoc->GetRecord(index, pDocRecord))
	{
		theListCtrl.InsertItem(index, "data corruption");
	}
	else
	{
		//note: the data entries must be null terminated for this to work:
		theListCtrl.InsertItem(index, pDocRecord->name);
		theListCtrl.SetItemText(index, 1, pDocRecord->address);
		theListCtrl.SetItemText(index, 2, pDocRecord->city   );
		theListCtrl.SetItemText(index, 3, pDocRecord->state  );
		theListCtrl.SetItemText(index, 4, pDocRecord->zipcode);

		//Clear existing selected item's selection state:
		POSITION pos = theListCtrl.GetFirstSelectedItemPosition();
		if(pos)
		{
			int nSelectedItem = theListCtrl.GetNextSelectedItem(pos);
			theListCtrl.SetItemState(nSelectedItem, 0, LVIS_SELECTED); 
		}
		//Set new selected item:
		theListCtrl.SetItemState(index, LVIS_SELECTED, LVIS_SELECTED); 

		SetQuoteInEditView(index);
	}

	//Readjust column widths. Some of the new items added may require a change of 
	//column width to be completely visible:
	for(UINT i = 0; i< m_numberOfListViewColumns; i++)
		theListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER); 

	theListCtrl.SetRedraw(TRUE);
	theListCtrl.Invalidate(); 

	delete pDocRecord;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CMyListView::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= LVS_SHOWSELALWAYS | LVS_REPORT;

	return CListView::PreCreateWindow(cs);
}
/////////////////////////////////////////////////////////////////////////////
void CMyListView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CListCtrl& theListCtrl = GetListCtrl();

	//clear selected item's selection state that was previously set:
	POSITION pos = theListCtrl.GetFirstSelectedItemPosition();
	int nSelectedItem = theListCtrl.GetNextSelectedItem(pos);
	theListCtrl.SetItemState(nSelectedItem, 0, LVIS_SELECTED); 

	//this will set a new item as being selected:
	CListView::OnLButtonDown(nFlags, point);

	int itemHit = theListCtrl.HitTest(point);
	SetQuoteInEditView(itemHit);
}
/////////////////////////////////////////////////////////////////////////////
void CMyListView::SetQuoteInEditView(UINT item)
{
	if(item == -1) //didn't hit on an item in listview
		return;

	CMyEditView*  pEditView = ((CMainFrame*)AfxGetMainWnd())->m_pEditView;
	if(!pEditView)
		return;
	CSDIViewSwitchDoc* pDoc = ((CSDIViewSwitchApp*)AfxGetApp())->m_pDoc;
	if(!pDoc)
		return;

	DOC_RECORD DocRecord;
	DOC_RECORD* pDocRecord = &DocRecord;
	if(!pDoc->GetRecord(item, pDocRecord))
	{
		pEditView->SetWindowText("data corruption");
	}
	else
	{
		pEditView->SetWindowText(pDocRecord->quote); //update Edit view
	}
}
/////////////////////////////////////////////////////////////////////////////
void CMyListView::OnInitialUpdate() 
{
	//because of the structure of this app, this function can be called more than once. 
	//The following flag insures the code after is only run once:
	if(m_bInitialized)
		return;
	m_bInitialized = true;

	((CMainFrame*)AfxGetMainWnd())->m_pListView = this;
	InitializeListView();
	CListView::OnInitialUpdate();
}
