// SplitterView.cpp : implementation file

#include "stdafx.h"
#include "SDIViewSwitch.h"
#include "MyTreeView.h"  // LeftPane View
#include "RightPaneHorizSplitterView.h"   // RightPane View
#include "SplitterView.h" 
#include "MainFrm.h"
#include "FormView1.h"
#include "FormView2.h"
#include "MyEditView.h"
#include "MyListView.h"
#include "SplitterView.h" 
#include "RightPaneVertSplitterView.h"
#include "NoFormViewInRightPaneHorizSplitterView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CSplitterView, CView)

CSplitterView::CSplitterView()
{
	m_pWndSplitter = NULL;
	m_bShouldSetXColumn = true;
	m_bInitialized = false;
}
/////////////////////////////////////////////////////////////////////////////
CSplitterView::~CSplitterView()
{
	TRACE("destructing CSplitterView\n");	
	m_pWndSplitter = NULL;
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CSplitterView, CView)
	//{{AFX_MSG_MAP(CSplitterView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_MESSAGE(XTWM_OUTBAR_NOTIFY, OnOutbarNotify)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
void CSplitterView::OnDraw(CDC* pDC)
{
	// TODO: add draw code here
}
/////////////////////////////////////////////////////////////////////////////
// CSplitterView diagnostics
#ifdef _DEBUG
void CSplitterView::AssertValid() const
{
	CView::AssertValid();
}

void CSplitterView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG
//////////////////////////////////////////////////////////////////////
int CSplitterView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	//Create the main splitter view. There are two panes (2 columns, 1 row).
	//The left pane is a tree view, the right pane is itself a splitter view.
	m_wndSplitter.CreateStatic(this, 1, 2);
	CCreateContext *pContext = (CCreateContext*)lpCreateStruct->lpCreateParams;
	lpCreateStruct->style |= WS_OVERLAPPED;
//////////////////////////////////////////////////////////////////
	if (!m_wndOutlookBar.Create(WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN, CRect(0,0,0,0),
		&m_wndSplitter, m_wndSplitter.IdFromRowCol(0, 0), OBS_XT_DEFAULT))
	{
		TRACE0("Failed to create outlook bar.");
		return FALSE;
	}

	m_wndOutlookBar.SetBackColor(RGB(255,255,255));
	m_wndOutlookBar.SetTextColor(RGB(0,0,0));

///////////////////////////////////////////////////////////////
	//m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(CMyTreeView), CSize(0,0), pContext);
	m_wndSplitter.CreateView(0,1,RUNTIME_CLASS(CRightPaneHorizSplitterView),  CSize(0,0), pContext);

	m_pWndSplitter = &m_wndSplitter;
	((CMainFrame*)GetParentFrame())->m_pNewView = this;  // could also use AfxGetMainWnd()
	InitializeOutlookBar();

	return 0; // OnCreate must return 0 to continue the creation of the CWnd object
}
//////////////////////////////////////////////////////////////////////
void CSplitterView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	m_wndSplitter.MoveWindow(0, 0, cx, cy);

	//We just want to set the X column upon creation of the view. This way the user can  
	//move the splitter bar to how they like it and still resize the frame window 
	//without it snapping back:
	if(m_bShouldSetXColumn) 
		m_wndSplitter.SetColumnInfo(0, cx/7, 0);

	m_wndSplitter.RecalcLayout();  
}
//////////////////////////////////////////////////////////////////////
void CSplitterView::OnInitialUpdate() 
{
	//Because of the structure of this app, this function can be called more than once. 
	//The following flag insures the code after is only run once:
	if(m_bInitialized)
		return;
	m_bInitialized = true;

	for(int i = 0; i<2; i++) //2 vertical panes (the right pane happens to have sub panes)
	{
		CView* pView = (CView*)m_wndSplitter.GetPane(0, i);
		pView->OnInitialUpdate();
	}

	TRACE("in CSplitterView::OnInitialUpdate()\n"); 
}
//////////////////////////////////////////////////////////////////////
static UINT nIcons[] =
{
    IDI_ICON12, IDI_ICON23,  IDI_ICON15,  IDI_ICON16,
		IDI_ICON17, IDI_ICON18,  IDI_ICON19, IDI_ICON20,
		IDI_ICON21, IDI_ICON22, IDI_ICON11
};

void CSplitterView::InitializeOutlookBar()
{
	m_ImageSmall.Create (32, 32, ILC_COLOR16|ILC_MASK, 2, 1);
	m_ImageLarge.Create (48, 48, ILC_COLOR16|ILC_MASK, 2, 1);
	m_ImageFolder.Create(16, 16, ILC_COLOR32|ILC_MASK, 2, 1);
	// initiailize the image lists.
	for (int i = 0; i < 11; ++i)
	{
		HICON hIcon = AfxGetApp()->LoadIcon(nIcons[i]);
		ASSERT(hIcon);
		
		m_ImageSmall.Add(hIcon);
		m_ImageLarge.Add(hIcon);
		m_ImageFolder.Add(hIcon);
	}

	


	int iFolder; // index of the added folder
	// set the image lists for the outlook bar.
	m_wndOutlookBar.SetImageList(&m_ImageLarge, OBS_XT_LARGEICON);
	m_wndOutlookBar.SetImageList(&m_ImageSmall, OBS_XT_SMALLICON);
	m_wndOutlookBar.SetFolderImageList(&m_ImageFolder);
	// Add the first folder to the outlook bar.
	iFolder = m_wndOutlookBar.AddFolder(_T("�绰��Ʒ"), 0);
	
	// Add items to the folder, syntax is folder, index, text, image, and item data.
	m_wndOutlookBar.InsertItem(iFolder, 1, _T("�ؿ��ʼ���"), 0, NULL);
	m_wndOutlookBar.InsertItem(iFolder, 2, _T("��ʧ�ͻ�"), 1, NULL);
	m_wndOutlookBar.InsertItem(iFolder, 3, _T("����Ԥ��"), 2, NULL);
	m_wndOutlookBar.InsertItem(iFolder, 4, _T("����ͳ��"), 3, NULL);
	m_wndOutlookBar.InsertItem(iFolder, 5, _T("����ͳ��"), 4, NULL);
	m_wndOutlookBar.InsertItem(iFolder, 6, _T("����ͳ��"), 5, NULL);
	
	// Add the second folder to the outlook bar.
	iFolder = m_wndOutlookBar.AddFolder(_T("Shortcuts 2"), 1);
	
	
	
	// Add items to the folder, syntax is folder, index, text, image, and item data.
	m_wndOutlookBar.InsertItem(iFolder, 7, _T("Item 7"), 7, 1);
	m_wndOutlookBar.InsertItem(iFolder, 8, _T("Item 8"), 8, 1);
	
	// Add the tree control to the outlook bar.
	//xu	iFolder = m_wndOutlookBar.AddFolderBar(_T("Tree Control"), &m_wndTreeCtrl );
	
	// Set the default font used by the outlook bar.
	//xu	m_wndOutlookBar.SetFontX(&xtAfxData.font);
	
	// We want to receive notification messages.
	m_wndOutlookBar.SetOwner(this);
	m_wndOutlookBar.SetSmallIconView(TRUE,0);
	// Select the first folder in the bar.
	m_wndOutlookBar.SetSelFolder(0);
	
	// Sizing for splitter
	//	m_wndSplitter1.SetSplitterStyle(XT_SPLIT_NOFULLDRAG);
	
}

LRESULT CSplitterView::OnOutbarNotify(WPARAM wParam, LPARAM lParam)
{
	int nBarAction = (int)wParam;
	
	// Cast the lParam to a XT_OUTBAR_INFO* struct pointer.
	XT_OUTBAR_INFO* pOBInfo = (XT_OUTBAR_INFO*)lParam;
	ASSERT(pOBInfo);
		int i;
	switch (nBarAction)
	{
	case OBN_XT_ITEMCLICK:
		{		
			CString strMsg=pOBInfo->lpszText;
			i=pOBInfo->nIndex;
			int p=pOBInfo->nDragTo;
			switch (i)
			{
			case 0:	m_pWndSplitter->ReplaceView(RUNTIME_CLASS(CFormView1));break;
			case 1:m_pWndSplitter->ReplaceView(RUNTIME_CLASS(CFormView2));break;
			case 2:m_pWndSplitter->ReplaceView(RUNTIME_CLASS(CMyEditView));break;
			case 3:m_pWndSplitter->ReplaceView(RUNTIME_CLASS(CMyListView));break;
			case 4:m_pWndSplitter->ReplaceView(RUNTIME_CLASS(CRightPaneHorizSplitterView));break;
			case 5:m_pWndSplitter->ReplaceView(RUNTIME_CLASS(CRightPaneVertSplitterView));break;


			}
		}
		break;
		
	case OBN_XT_FOLDERCHANGE:
		TRACE2( "Folder selected: %d, Name: %s.\n", pOBInfo->nIndex, pOBInfo->lpszText);
		break;
		
	case OBN_XT_ONLABELENDEDIT:
		TRACE2( "Item edited: %d, New name: %s.\n", pOBInfo->nIndex, pOBInfo->lpszText);
		break;
		
	case OBN_XT_ONGROUPENDEDIT:
		TRACE2( "Folder edited: %d, New name: %s.\n", pOBInfo->nIndex, pOBInfo->lpszText);
		break;
		
	case OBN_XT_DRAGITEM:
		TRACE3( "Dragging From: %d, To: %d, Name: %s.\n", pOBInfo->nDragFrom, pOBInfo->nDragTo, pOBInfo->lpszText);
		break;
		
	case OBN_XT_ITEMHOVER:
		TRACE2( "Hovering Item: %d, Name: %s.\n", pOBInfo->nIndex, pOBInfo->lpszText);
		break;
		
	case OBN_XT_DELETEITEM:
		
		if (!m_bDestroy && AfxMessageBox(_T("Are you sure you want to remove this folder shortcut?"),
			MB_ICONWARNING|MB_YESNO) == IDNO)
		{
			// The user selected No, return FALSE to abort the action.
			return FALSE;
		}
		TRACE2( "Item deleted: %d, Name: %s.\n", pOBInfo->nIndex, pOBInfo->lpszText);
		break;
		
	case OBN_XT_DELETEFOLDER:
		if (!m_bDestroy && AfxMessageBox(_T("Are you sure you want to remove the specified folder?"),
			MB_ICONWARNING|MB_YESNO) == IDNO)
		{
			// The user selected No, return FALSE to abort the action.
			return FALSE;
		}
		TRACE2( "Folder deleted: %d, Name: %s.\n", pOBInfo->nIndex, pOBInfo->lpszText);
		break;
	}
	
	return TRUE;
}