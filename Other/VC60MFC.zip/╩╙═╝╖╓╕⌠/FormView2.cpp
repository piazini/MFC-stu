// FormView2.cpp : implementation file

#include "stdafx.h"
#include "SDIViewSwitch.h"
#include "FormView2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CFormView2, CColorFormView)

CFormView2::CFormView2()
	: CColorFormView(CFormView2::IDD, RGB(250, 167, 99)) //orange
{
	//{{AFX_DATA_INIT(CFormView2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CFormView2::~CFormView2()
{
	TRACE("destructing CFormView2\n");
}

void CFormView2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFormView2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFormView2, CColorFormView)
	//{{AFX_MSG_MAP(CFormView2)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFormView2 diagnostics
#ifdef _DEBUG
void CFormView2::AssertValid() const
{
	CFormView::AssertValid();
}

void CFormView2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
void CFormView2::OnCheck1() 
{
	TRACE("In CFormView2::OnCheck1()\n");	
}
