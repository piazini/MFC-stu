#if !defined(AFX_MYEDITVIEW_H__1EE667BF_3C2A_11D2_B145_00C04FB9CA2B__INCLUDED_)
#define AFX_MYEDITVIEW_H__1EE667BF_3C2A_11D2_B145_00C04FB9CA2B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyEditView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyEditView view

class CMyEditView : public CEditView
{
protected:
	CMyEditView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMyEditView)

// Attributes
public:
	bool m_bInitialized;
	CString m_defaultText;
	COLORREF m_clrCtlBkgnd;
	COLORREF m_clrText;
	COLORREF m_clrViewBkgnd;
	CBrush m_brCtlBkgnd;
	CBrush m_brViewBkgnd;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyEditView)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMyEditView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CMyEditView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYEDITVIEW_H__1EE667BF_3C2A_11D2_B145_00C04FB9CA2B__INCLUDED_)
