// MainFrm.cpp : implementation of the CMainFrame class

#include "stdafx.h"
#include "SDIViewSwitch.h"
#include "FormView1.h"
#include "FormView2.h"
#include "MyEditView.h"
#include "SplitterView.h"  //double paned vertical splitter (the right pane also has sub-panes)
#include "RightPaneHorizSplitterView.h"
#include "NoFormViewInRightPaneHorizSplitterView.h"
#include "MyTreeView.h"
#include "MainFrm.h"
#include "urlmon.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_MICROSOFT_HOME, OnMicrosoftHome)
	ON_WM_SIZE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	ON_COMMAND_RANGE(ID_VIEW_FORMVIEW1, ID_VIEW_SPLITTER, OnChooseView)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_FORMVIEW1, ID_VIEW_SPLITTER, OnUpdateViewMenuUI)
	ON_COMMAND(ID_ADD_FORM_VIEW, OnAddFormView)
	ON_COMMAND(ID_REMOVE_FORM_VIEW, OnRemoveFormView)
	ON_UPDATE_COMMAND_UI(ID_ADD_FORM_VIEW, OnUpdateAddFormView)
	ON_UPDATE_COMMAND_UI(ID_REMOVE_FORM_VIEW, OnUpdateRemoveFormView)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
CMainFrame::CMainFrame()
{
	m_pNewView  = NULL;
	m_pListView = NULL;
	m_pEditView = NULL;
	m_nCurrentView = ID_VIEW_SPLITTER;

	m_bShowingFormView3InRightPaneHorizSplitter = false; 
}
/////////////////////////////////////////////////////////////////////////////
CMainFrame::~CMainFrame()
{
	TRACE("destructing CMainFrame\n");
}
/////////////////////////////////////////////////////////////////////////////
//the following function is passed into EnumChildWindows() used in CMainFrame::OnChooseView()
BOOL CALLBACK CMainFrame::MyWndEnumProc(HWND hWnd, LPARAM ppWndLPARAM)
{
	CWnd* pWndChild = CWnd::FromHandlePermanent(hWnd);
	CWnd** ppWndTemp = (CWnd**)ppWndLPARAM;

	if( pWndChild && pWndChild->IsKindOf(RUNTIME_CLASS(CView)) )
	{   
		//any view that is found will work:
		*ppWndTemp = pWndChild; //pass ptr to found CView back to calling function
		return FALSE; //stop enumeration 
	}
	else
	{
		*ppWndTemp = NULL; 
		return TRUE;  //continue enumeration
	}
}
/////////////////////////////////////////////////////////////////////////////
//This function displays a view that is chosen from the toolbar or menu. There 
//are five types to choose from: FormView1, FormView2, EditView, ListView, and SplitterView
void CMainFrame::OnChooseView(UINT nCmdID) 
{
	if(nCmdID == m_nCurrentView)
		return; //view is already selected, so don't need to destroy it and then create it again

	CSDIViewSwitchDoc* pDoc = ((CSDIViewSwitchApp*)AfxGetApp())->m_pDoc;
	if(!pDoc)  //most likely a problem reading in file
	{
		AfxMessageBox("A problem occurred. Try to open a new file. If that"
			"doesn't work, please close the application and run it again");
		return;
	}

	CWnd* pWnd;
	CWnd* pWndToDelete;

	//The use of EnumChildWindows below is to find a child window that is derived from CView.
	//GetActiveView() will return NULL if no view has focus, so we can't use it here.
	//GetActiveDocument() also can't be used because it calls GetActiveView().
	::EnumChildWindows(m_hWnd, MyWndEnumProc, (LPARAM)&(pWnd));

	if(pWnd == NULL)
	{
		AfxMessageBox("Problem: CMainFrame::OnChooseView can not find any views!");
		return;
	}

	//Now that we've found a view, search up the parent tree until we come to the CMainFrame 
	//window. Then set pWndToDelete to the CWnd that is the immediate child of CMainFrame. 
	//This is done to find the most senior view (which may or may not have children views). 
	//CMainFrame also has children, such as the toolbar, that we don't want to delete.
	while( lstrcmp(pWnd->GetRuntimeClass()->m_lpszClassName, "CMainFrame") )
	{
		pWndToDelete = pWnd;
		pWnd = pWnd->GetParent();
	}

	CRuntimeClass* pNewViewRTClass;
	switch(nCmdID)
	{
		case ID_VIEW_FORMVIEW1:
			pNewViewRTClass = RUNTIME_CLASS(CFormView1);
			break;
		case ID_VIEW_FORMVIEW2:
			pNewViewRTClass = RUNTIME_CLASS(CFormView2);
			break;
		case ID_VIEW_EDITVIEW:
			pNewViewRTClass = RUNTIME_CLASS(CMyEditView);
			break;
		case ID_VIEW_LISTVIEW: 
			pNewViewRTClass = RUNTIME_CLASS(CMyListView);	
			break;
		case ID_VIEW_SPLITTER:
			pNewViewRTClass = RUNTIME_CLASS(CSplitterView);
			break;
		default:
			ASSERT(0);
			return;
	}
	
	//Create the new view:
	CCreateContext context;
	context.m_pNewViewClass = pNewViewRTClass;
	context.m_pCurrentDoc = pDoc;

	m_pNewView = STATIC_DOWNCAST(CView, CreateView(&context));
	if(m_pNewView != NULL)
	{
		m_nCurrentView = nCmdID;

		//Make sure that the document won't be destroyed when the view is destroyed.
		//m_bAutoDelete is a public, but non-documented member of CDocument.
		pDoc->m_bAutoDelete = FALSE;    

		//destroy the old view:
		pWndToDelete->DestroyWindow(); 

		//OnInitialUpdate() is not called as a result of calling CreateView() above. 
		//It is not always called by the framework, so it is called here:
		m_pNewView->OnInitialUpdate(); 

		//Show and activate view:
		m_pNewView->ShowWindow(SW_SHOW); 
		SetActiveView(m_pNewView);
		RecalcLayout();
	}
	else
	{
		AfxMessageBox("problem creating a view in CMainFrame::OnChooseView()");
	}
}
/////////////////////////////////////////////////////////////////////////////
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndToolBar.LoadTrueColorToolBar( 48, IDB_HOT, IDB_HOT, IDB_HOT);
	CRect rect; 
	GetClientRect(&rect);
	m_wndToolBar.SetButtonInfo(0, 1000, TBBS_SEPARATOR, rect.Width()/7) ; 
	m_wndToolBar.GetItemRect(0, &rect); 
	//	rect.bottom += 100;
	m_Static.Create("",WS_CHILD|WS_VISIBLE|SS_CENTER, rect,&m_wndToolBar,1000);

	if (!m_wndStatusBar.Create(this) || !m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	//For some reason, CBRS_SIZE_DYNAMIC doesn't work correctly with the the way this app dynamically 
	//adds and removes toolbar buttons from a floating toolbar. So, we must not use this style here:
	m_wndToolBar.SetBarStyle( m_wndToolBar.GetBarStyle() | CBRS_TOOLTIPS | CBRS_FLYBY ); 

	//There is a also a slight problem when dynamically adding toolbar buttons to a toolbar docked to
	//the left and right sides of the frame window, so don't use CBRS_ALIGN_ANY below:
	m_wndToolBar.EnableDocking(CBRS_ALIGN_TOP|CBRS_ALIGN_BOTTOM);
	EnableDocking(CBRS_ALIGN_TOP|CBRS_ALIGN_BOTTOM); 
	DockControlBar(&m_wndToolBar);
//	SetMenu(NULL);
	//set the application's caption bar:
	SetWindowText ("Welcome to SwitchSplit !");
	return 0;
}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics
#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style &= ~FWS_ADDTOTITLE; //gets rid of "Untitled" in the frame window caption
	BOOL bReturn = CFrameWnd::PreCreateWindow(cs);

	//CFrameWnd::PreCreateWindow(cs) sets some extended styles that need to be removed 
	//in this app. One of them is WS_EX_OVERLAPPEDWINDOW. If this style isn't removed,
	//there will be a window border problem.
	cs.dwExStyle &= ~WS_EX_OVERLAPPEDWINDOW;  
		
	return bReturn;
}
/////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnUpdateViewMenuUI(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(pCmdUI->m_nID == m_nCurrentView);
}
/////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnAddFormView() 
{
	//the following if statement should always be true, but it's here just as a safeguard:
	if( (m_nCurrentView == ID_VIEW_SPLITTER)  && m_pNewView)
	{
		CMySplitterWnd* pMainSplitterWnd = ((CSplitterView*)m_pNewView)->m_pWndSplitter;
		if(pMainSplitterWnd->ReplaceView(RUNTIME_CLASS(CRightPaneHorizSplitterView)))
			m_bShowingFormView3InRightPaneHorizSplitter = true;
	}
}
////////////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnRemoveFormView() 
{
	//the following if statement should always be true, but it's here just as a safeguard:
	if( (m_nCurrentView == ID_VIEW_SPLITTER)  && m_pNewView)
	{
		CMySplitterWnd* pMainSplitterWnd = ((CSplitterView*)m_pNewView)->m_pWndSplitter;
		if(pMainSplitterWnd->ReplaceView(RUNTIME_CLASS(CNoFormViewInRightPaneHorizSplitterView)))
			m_bShowingFormView3InRightPaneHorizSplitter = false;
	}
}
////////////////////////////////////////////////////////////////////////////////////
//enables or disables the "+" button, or the corresponding "Add Form View 3" menu item:
void CMainFrame::OnUpdateAddFormView(CCmdUI* pCmdUI) 
{
	//The only time this button should be visible is when m_nCurrentView == ID_VIEW_SPLITTER, 
	//so checking this condition is just a safeguard.
	pCmdUI->Enable(m_nCurrentView == ID_VIEW_SPLITTER &&
		!m_bShowingFormView3InRightPaneHorizSplitter);
}
////////////////////////////////////////////////////////////////////////////////////
//enables or disables the "-" button, or the corresponding "Remove Form View 3" menu item:
void CMainFrame::OnUpdateRemoveFormView(CCmdUI* pCmdUI) 
{   
	//The only time this button should be visible is when m_nCurrentView == ID_VIEW_SPLITTER, 
	//so checking this condition is just a safeguard.
	pCmdUI->Enable(m_nCurrentView == ID_VIEW_SPLITTER &&
		m_bShowingFormView3InRightPaneHorizSplitter);
}
/////////////////////////////////////////////////////////////////////////////////////////
void CMainFrame::AlterFrameForFormView3(bool bShowingRightPaneHorizSplitterView)
{
	//We are not adding and removing all view specific menu items and toolbar buttons. The only view 
	//specific items that are being added and removed are the buttons and menu items that
	//show and remove FormView3.For example, the menu items and toolbar buttons that pertain to the 
	//editview (undo, cut, copy and paste) are left there for all views. This is the usual approach.
	//They are just grayed out when their respective view is not being displayed, or does not 
	//have the focus.

	if(m_hWnd == NULL)
		return;

	CToolBarCtrl& toolbarCtrl = m_wndToolBar.GetToolBarCtrl(); 
	//In destroying the frame window, the toolbar is destroyed before the view, so must check:
	if(toolbarCtrl.m_hWnd == NULL) 
		return;

	CMenu* pMainMenu = GetMenu();
	if(pMainMenu == NULL || pMainMenu->m_hMenu == NULL)
		return;
	CMenu* pViewPopupMenu = pMainMenu->GetSubMenu(2); 

	if(bShowingRightPaneHorizSplitterView)
	{
		//show menu items:
		pViewPopupMenu->InsertMenu(4, MF_BYPOSITION, MF_SEPARATOR);
		pViewPopupMenu->InsertMenu(6, MF_BYPOSITION, ID_REMOVE_FORM_VIEW, "   &Remove Form View 3"); 
		pViewPopupMenu->InsertMenu(6, MF_BYPOSITION, ID_ADD_FORM_VIEW, "   &Add       Form View 3");  

		//show toolbar buttons:
		toolbarCtrl.HideButton(ID_ADD_FORM_VIEW, FALSE);
		toolbarCtrl.HideButton(ID_REMOVE_FORM_VIEW, FALSE);
	}
	else
	{
		//remove menu items:
		pViewPopupMenu->DeleteMenu(4, MF_BYPOSITION);
		pViewPopupMenu->DeleteMenu(ID_ADD_FORM_VIEW, MF_BYCOMMAND);
		pViewPopupMenu->DeleteMenu(ID_REMOVE_FORM_VIEW, MF_BYCOMMAND);

		//remove toolbar buttons:
		toolbarCtrl.HideButton(ID_ADD_FORM_VIEW, TRUE);
		toolbarCtrl.HideButton(ID_REMOVE_FORM_VIEW, TRUE);
	}

	if(m_wndToolBar.IsFloating())  //toolbar is floating in it's own miniframe window:
	{
		CMiniFrameWnd* pMiniFrameWnd = (CMiniFrameWnd*)m_wndToolBar.GetParentFrame();
		pMiniFrameWnd->RecalcLayout();
		pMiniFrameWnd->ShowWindow(SW_SHOWNA);
		pMiniFrameWnd->UpdateWindow();
	}
	else //toolbar is docked to the frame
	{
		RecalcLayout(); 
	}
}
/////////////////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnClose() 
{   
	//We must make sure that this member variable of the document object (m_bAutoDelete)
	//is set to be deleted when the frame is destroyed. If we don't, there will be a 
	//memory leak when closing down the app.
	CSDIViewSwitchApp* pApp = (CSDIViewSwitchApp*)AfxGetApp();
	if(pApp && pApp->m_pDoc)
		pApp->m_pDoc->m_bAutoDelete = TRUE;	

	CFrameWnd::OnClose();
}
/////////////////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnMicrosoftHome() 
{
	::HlinkNavigateString(NULL, L"http://www.microsoft.com");		
}

void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
	CFrameWnd::OnSize(nType, cx, cy);
	CRect rect; 
	GetClientRect(&rect);
	m_wndToolBar.SetButtonInfo(0, 1000, TBBS_SEPARATOR, rect.Width()/7) ; 
	m_wndToolBar.GetItemRect(0, &rect); 
	m_Static.SetWindowPos(NULL,0,0,rect.Width(),rect.Height(),0);
	// TODO: Add your message handler code here
	
}

void CMainFrame::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// Do not call CFrameWnd::OnPaint() for painting messages
}

void CMainFrame::DrawTitleBar(CDC *pDC)
{
	
	CRect rtWnd, rtTitle, rtButtons;
	GetWindowRect(&rtWnd); 
	//ȡ�ñ�������λ��
	rtTitle.left = GetSystemMetrics(SM_CXFRAME);
	rtTitle.top = GetSystemMetrics(SM_CYFRAME);
	rtTitle.right = rtWnd.right - rtWnd.left - GetSystemMetrics(SM_CXFRAME);
	rtTitle.bottom = rtTitle.top + GetSystemMetrics(SM_CYSIZE);
	CBitmap* pBitmap = new CBitmap;
	BITMAP BmpInfo;
	CBitmap* pOldBitmap;
	CDC* pDisplayMemDC=new CDC;
	pDisplayMemDC->CreateCompatibleDC(pDC);
	POINT  DrawPonit;
	DrawPonit.x =	rtTitle.left-4;
	DrawPonit.y =	rtTitle.top-4;
	pBitmap->LoadBitmap(IDB_TOP);
	pOldBitmap=(CBitmap*)pDisplayMemDC->SelectObject(pBitmap);
	pBitmap->GetBitmap(&BmpInfo);
	while(DrawPonit.x<= rtTitle.right+1) 
	{
		pDC->BitBlt(DrawPonit.x, DrawPonit.y, BmpInfo.bmWidth, BmpInfo.bmHeight, pDisplayMemDC, 0, 0, SRCCOPY);
		DrawPonit.x = DrawPonit.x + BmpInfo.bmWidth;
	}
	pBitmap->DeleteObject();

////////
	//�ػ��ر�button
	rtButtons.left = rtTitle.right - 42;
	rtButtons.top = rtTitle.top;
	rtButtons.right = rtButtons.left + 42;
	rtButtons.bottom = rtButtons.top + 18;
	pBitmap->LoadBitmap(IDB_CLOSE_NORMAL);
	pOldBitmap=(CBitmap*)pDisplayMemDC->SelectObject(pBitmap);
	pDC->BitBlt(rtButtons.left, rtButtons.top, rtButtons.Width(), rtButtons.Height(), pDisplayMemDC, 0, 0, SRCCOPY);
	pDisplayMemDC->SelectObject(pOldBitmap);
	m_rtButtClose = rtButtons;
	m_rtButtClose.OffsetRect(rtWnd.TopLeft()); 
	pBitmap->DeleteObject();
	
	//�ػ����/�ָ�button
	rtButtons.right = rtButtons.left;
	rtButtons.left = rtButtons.right - 26;
	if (IsZoomed())
		pBitmap->LoadBitmap(IDB_RESTORE_NORMAL);
	else
		pBitmap->LoadBitmap(IDB_MAX_NORMAL);
	pOldBitmap=(CBitmap*)pDisplayMemDC->SelectObject(pBitmap);
	pDC->BitBlt(rtButtons.left, rtButtons.top, rtButtons.Width(), rtButtons.Height(), pDisplayMemDC, 0, 0, SRCCOPY);
	pDisplayMemDC->SelectObject(pOldBitmap);
	m_rtButtMax = rtButtons;
	m_rtButtMax.OffsetRect(rtWnd.TopLeft());
	pBitmap->DeleteObject();
	
	//�ػ���С��button
	rtButtons.right = rtButtons.left;
	rtButtons.left = rtButtons.right - 25;
	pBitmap->LoadBitmap(IDB_MIN_NORMAL);
	pOldBitmap=(CBitmap*)pDisplayMemDC->SelectObject(pBitmap);
	pDC->BitBlt(rtButtons.left, rtButtons.top, rtButtons.Width(), rtButtons.Height(), pDisplayMemDC, 0, 0, SRCCOPY);
	pDisplayMemDC->SelectObject(pOldBitmap);
	m_rtButtMin = rtButtons;
	m_rtButtMin.OffsetRect(rtWnd.TopLeft());
	pBitmap->DeleteObject();

	////

	pDisplayMemDC->SelectObject(pOldBitmap);
	pBitmap->DeleteObject();




	ReleaseDC(pDisplayMemDC);
	delete pDisplayMemDC;
	delete pBitmap;

}

LRESULT CMainFrame::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	if (message==WM_MOVE||message==WM_PAINT||message==WM_NCPAINT||message==WM_NCACTIVATE ||message == WM_NOTIFY)
	{
		CDC* pWinDC = GetWindowDC();
		if (pWinDC)
			DrawTitleBar(pWinDC);
		ReleaseDC(pWinDC);
	}

	return CFrameWnd::DefWindowProc(message, wParam, lParam);
}
