// RightPaneVertSplitterView.cpp : implementation file

#include "stdafx.h"
#include "sdiviewswitch.h"
#include "RightPaneVertSplitterView.h"
#include "FormView3.h"
#include "MyEditView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CRightPaneVertSplitterView, CView)

CRightPaneVertSplitterView::CRightPaneVertSplitterView()
{
	m_bInitialized = false;
}

CRightPaneVertSplitterView::~CRightPaneVertSplitterView()
{
	TRACE("destructing CRightPaneVertSplitterView\n");	
}

BEGIN_MESSAGE_MAP(CRightPaneVertSplitterView, CView)
	//{{AFX_MSG_MAP(CRightPaneVertSplitterView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
void CRightPaneVertSplitterView::OnDraw(CDC* pDC)
{
	// TODO: add draw code here
}
/////////////////////////////////////////////////////////////////////////////
// CRightPaneVertSplitterView diagnostics
#ifdef _DEBUG
void CRightPaneVertSplitterView::AssertValid() const
{
	CView::AssertValid();
}

void CRightPaneVertSplitterView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
int CRightPaneVertSplitterView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	//Create a splitter window with 2 panes in the same row (2 columns).
	//The 8 added to AFX_IDW_PANE_FIRST below is pretty arbitrary:
	m_WndRightPaneSplitter.CreateStatic(this, 1, 2, WS_CHILD|WS_VISIBLE, AFX_IDW_PANE_FIRST+8);
	CCreateContext *pContext = (CCreateContext*) lpCreateStruct->lpCreateParams;
	m_WndRightPaneSplitter.CreateView(0,0, RUNTIME_CLASS(CFormView3), CSize(0,0), pContext);
	m_WndRightPaneSplitter.CreateView(0,1, RUNTIME_CLASS(CMyEditView), CSize(0,0), pContext);	

	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////
void CRightPaneVertSplitterView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	//Increase size by 2 all around to hide border:
	m_WndRightPaneSplitter.MoveWindow(-2, -2, cx+2, cy+2); 
	m_WndRightPaneSplitter.SetColumnInfo(0, cx/2, 0);
	m_WndRightPaneSplitter.RecalcLayout();  
}
///////////////////////////////////////////////////////////////////////////////////////
void CRightPaneVertSplitterView::OnInitialUpdate() 
{
	//Because of the structure of this app, this function can be called more than once. 
	//The following flag insures the code after is only run once:
	if(m_bInitialized)
		return;
	m_bInitialized = true;

	for(int i = 0; i<2; i++) //3 views in this pane
	{
		CView* pView = (CView*)m_WndRightPaneSplitter.GetPane(0, 1);
		pView->OnInitialUpdate();
	}	
}
