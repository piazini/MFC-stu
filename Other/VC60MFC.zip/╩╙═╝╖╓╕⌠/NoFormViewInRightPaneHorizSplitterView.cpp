// NoFormViewInRightPaneHorizSplitterView.cpp : implementation file

#include "stdafx.h"
#include "sdiviewswitch.h"
#include "NoFormViewInRightPaneHorizSplitterView.h"
#include "MyEditView.h"
#include "MyListView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CNoFormViewInRightPaneHorizSplitterView, CView)

CNoFormViewInRightPaneHorizSplitterView::CNoFormViewInRightPaneHorizSplitterView()
{
	m_bInitialized = false;
}
/////////////////////////////////////////////////////////////////////////////
CNoFormViewInRightPaneHorizSplitterView::~CNoFormViewInRightPaneHorizSplitterView()
{
	TRACE("destructing CNoFormViewInRightPaneHorizSplitterView\n");	
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CNoFormViewInRightPaneHorizSplitterView, CView)
	//{{AFX_MSG_MAP(CNoFormViewInRightPaneHorizSplitterView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
void CNoFormViewInRightPaneHorizSplitterView::OnDraw(CDC* pDC)
{
	// TODO: Add your specialized code here and/or call the base class
}
/////////////////////////////////////////////////////////////////////////////
// CNoFormViewInRightPaneHorizSplitterView diagnostics
#ifdef _DEBUG
void CNoFormViewInRightPaneHorizSplitterView::AssertValid() const
{
	CView::AssertValid();
}

void CNoFormViewInRightPaneHorizSplitterView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
int CNoFormViewInRightPaneHorizSplitterView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_WndRightPaneSplitter.CreateStatic(this, 2, 1, WS_CHILD|WS_VISIBLE, AFX_IDW_PANE_FIRST+8);
	CCreateContext *pContext = (CCreateContext*) lpCreateStruct->lpCreateParams;
	CSize size(0,0);
	m_WndRightPaneSplitter.CreateView(0,0, RUNTIME_CLASS(CMyEditView), size, pContext);
	m_WndRightPaneSplitter.CreateView(1,0, RUNTIME_CLASS(CMyListView), size, pContext);

	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////
void CNoFormViewInRightPaneHorizSplitterView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	//Increase size by 2 all around to hide border:
	m_WndRightPaneSplitter.MoveWindow(-2, -2, cx+2, cy+2); 
	m_WndRightPaneSplitter.SetRowInfo(0, cy/2, 0);
	m_WndRightPaneSplitter.RecalcLayout();  
}
////////////////////////////////////////////////////////////////////////////////////////////
void CNoFormViewInRightPaneHorizSplitterView::OnInitialUpdate() 
{
	//Because of the structure of this app, when the frame is created, this function
	//is called more than once. The following flag insures the code after is only run once:
	if(m_bInitialized)
		return;
	m_bInitialized = true;

	for(int i = 0; i<2; i++) //2 views in this pane
	{
		CView* pView = (CView*)m_WndRightPaneSplitter.GetPane(i, 0);
		pView->OnInitialUpdate();
	}
	
	((CMainFrame*)AfxGetMainWnd())->AlterFrameForFormView3();		
}
////////////////////////////////////////////////////////////////////////////////////////////
void CNoFormViewInRightPaneHorizSplitterView::OnDestroy() 
{
	CView::OnDestroy();
	
	CMainFrame* pFrameWnd = (CMainFrame*)GetParentFrame();
	if(pFrameWnd == NULL || pFrameWnd->m_hWnd == NULL)
		return;
	pFrameWnd->AlterFrameForFormView3(false);	
}
