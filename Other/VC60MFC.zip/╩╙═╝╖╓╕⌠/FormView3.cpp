// FormView3.cpp : implementation file

#include "stdafx.h"
#include "SDIViewSwitch.h"
#include "FormView3.h"
#include "MainFrm.h"
#include "SDIViewSwitchDoc.h"
#include "MyEditView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
void AFXAPI DDV_MinString(CDataExchange* pDX, CString const& str)
{
	//a very simple custom DDV routine:
	if(str.IsEmpty())
	{
		if(!pDX->m_bSaveAndValidate)
		{
			return;     
		}
		AfxMessageBox("String needs to have at least one character.");
		pDX->Fail();
	}
}
/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CFormView3, CColorFormView)

CFormView3::CFormView3()
	: CColorFormView(CFormView3::IDD, RGB(122, 188, 105)) //a green color
{
	//{{AFX_DATA_INIT(CFormView3)
	m_strAddress = _T("");
	m_strCity = _T("");
	m_strName = _T("");
	m_strState = _T("");
	m_strZipCode = _T("");
	//}}AFX_DATA_INIT

	//The following color will be used to "override" the default edit color that 
	//is coded in the CColorFormView class that this formview is derived from:
	m_crGreen = RGB(200,240,200); //very light green for edit windows
	m_pEditBkBrush = new CBrush(m_crGreen);
}
/////////////////////////////////////////////////////////////////////////////
CFormView3::~CFormView3()
{
	TRACE("destructing CFormView3\n");
}
/////////////////////////////////////////////////////////////////////////////
void CFormView3::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CFormView3)
	DDX_Text(pDX, IDC_EDIT_ADDRESS, m_strAddress);
	DDV_MaxChars(pDX, m_strAddress, 39);
	DDX_Text(pDX, IDC_EDIT_CITY, m_strCity);
	DDV_MaxChars(pDX, m_strCity, 23);
	DDX_Text(pDX, IDC_EDIT_STATE, m_strState);
	DDV_MaxChars(pDX, m_strState, 2);
	DDX_Text(pDX, IDC_EDIT_ZIPCODE, m_strZipCode);
	DDV_MaxChars(pDX, m_strZipCode, 5);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
	DDV_MaxChars(pDX, m_strName, 31);
	//}}AFX_DATA_MAP

	//My own very simple custom DDV that just checks that someone has entered 
	//something in the edit control. I could do this for all of the edit controls,
	//but I don't want to bother the user in filling out the entire form. Note that I
	//put the line DDX_Text(pDX, IDC_EDIT_NAME, m_strName) last in the data map above. 
	//The reason is that when the validation fails, focus will be returned to the last 
	//control that was "exchanged". If this were a "real" app, you'd probably want to
	//combine DDV_MaxChars with DDV_MinString to create one DDV routine.
	DDV_MinString(pDX, m_strName); //this must come after the DDX_Text for m_strName
	//and not before another DDX_...
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CFormView3, CColorFormView)
	//{{AFX_MSG_MAP(CFormView3)
	ON_BN_CLICKED(IDC_BUT_SUBMIT, OnSubmitData)
	ON_WM_CTLCOLOR()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CFormView3 diagnostics
#ifdef _DEBUG
void CFormView3::AssertValid() const
{
	CFormView::AssertValid();
}

void CFormView3::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
void CFormView3::OnSubmitData() 
{
	if(!UpdateData(TRUE)) // if not all data fits the correct form,
		return;	          // then try again ...

	//get document to update:
	CSDIViewSwitchDoc* pDoc = ((CSDIViewSwitchApp*)AfxGetApp())->m_pDoc;
	if(!pDoc)
		return;

	//update number of records in document:
	UINT nRecordIndex = (pDoc->m_nNumberOfRecords)++;
	//and change this number which is found in the document's header:
	pDoc->WriteHeader();

	DOC_RECORD* pDocRecord = new DOC_RECORD;
	::ZeroMemory(pDocRecord, sizeof(DOC_RECORD));

    //Get text from editview that is displayed adjacent to this formview
	CString strEditView;
	CMyEditView* pEditView = ((CMainFrame*)AfxGetMainWnd())->m_pEditView;
	if(pEditView) 
		pEditView->GetWindowText(strEditView); 
	else
		AfxMessageBox("no adjacent edit view!"); //should never get to this line

	//take data submitted and write it to the document:
	strncpy(pDocRecord->name,     m_strName   , 32 );
	strncpy(pDocRecord->address,  m_strAddress, 40 );
	strncpy(pDocRecord->city,     m_strCity   , 24 );
	strncpy(pDocRecord->state,    m_strState  , 4  );
	strncpy(pDocRecord->zipcode,  m_strZipCode, 8  );
	strncpy(pDocRecord->quote,    strEditView , 400);

	ClearForm();

	//write new data just added to document to a file:
	pDoc->UpdateRecord(nRecordIndex, pDocRecord);

	//show new data in the listview (if one is visible):
	AddItemToListView(nRecordIndex);

	delete pDocRecord;
}
/////////////////////////////////////////////////////////////////////////////
void CFormView3::AddItemToListView(UINT nRecordIndex)
{
	//check to see if a listview is being displayed before showing new item added:
	CMainFrame* pFrameWnd = (CMainFrame*)AfxGetMainWnd();
	CMyListView* pListView = pFrameWnd->m_pListView;
	if(pListView)
	{
		CSDIViewSwitchDoc* pDoc = ((CSDIViewSwitchApp*)AfxGetApp())->m_pDoc;
		pListView->AddNewItem(nRecordIndex, pDoc);
	}
}
/////////////////////////////////////////////////////////////////////////////
void CFormView3::ClearForm()
{
	m_strName    = "";
	m_strAddress = "";
	m_strCity    = "";
	m_strName    = "";
	m_strState   = "";
	m_strZipCode = "";
	UpdateData(FALSE);
}
/////////////////////////////////////////////////////////////////////////////
HBRUSH CFormView3::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	switch (nCtlColor) 
	{   //set color, and background text color for edit controls in this formview:
		case CTLCOLOR_EDIT: 
        	pDC->SetTextColor(RGB(0, 0, 0));
            pDC->SetBkColor(m_crGreen); 
             return *m_pEditBkBrush;
        default:
             return CColorFormView::OnCtlColor(pDC, pWnd, nCtlColor);          
	}
}
/////////////////////////////////////////////////////////////////////////////
void CFormView3::OnDestroy() 
{
	CFormView::OnDestroy();
	
	// Free the memory allocated for the background brush
    delete m_pEditBkBrush;	
}
/////////////////////////////////////////////////////////////////////////////
