// MyEditView.cpp : implementation file
//

#include "stdafx.h"
#include "sdiviewswitch.h"
#include "MyEditView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CMyEditView, CEditView)

CMyEditView::CMyEditView()
{
	m_bInitialized = false;

	m_clrText      = RGB(  0,  0,  0); //black
	m_clrCtlBkgnd  = RGB(200,200,240); //light violet 
	m_clrViewBkgnd = RGB(150,150,240); //dark  violet
	m_brCtlBkgnd .CreateSolidBrush(m_clrCtlBkgnd);
	m_brViewBkgnd.CreateSolidBrush(m_clrViewBkgnd);

	m_defaultText = 
		"There is a tide in the affairs of men\r\n"  
		"Which, taken at the flood, leads on to fortune.\r\n"
		"Omitted, all the voyage of their life\r\n"
		"Is bound in shallows and in miseries.\r\n\r\n"
		"William Shakespeare (1564-1616). Brutus, in Julius Caesar, act 4, sc. 2.";
}
/////////////////////////////////////////////////////////////////////////////
CMyEditView::~CMyEditView()
{
	TRACE("destructing CMyEditView\n");
	CMainFrame* pFrameWnd = ((CMainFrame*)AfxGetMainWnd());
	if(pFrameWnd)
		pFrameWnd->m_pEditView = NULL;	
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CMyEditView, CEditView)
	//{{AFX_MSG_MAP(CMyEditView)
	ON_WM_ERASEBKGND()
	ON_WM_CTLCOLOR_REFLECT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
void CMyEditView::OnDraw(CDC* pDC)
{
	// TODO: add draw code here
}
/////////////////////////////////////////////////////////////////////////////
// CMyEditView diagnostics

#ifdef _DEBUG
void CMyEditView::AssertValid() const
{
	CEditView::AssertValid();
}

void CMyEditView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
BOOL CMyEditView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
	const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	dwStyle |= WS_VSCROLL;
	BOOL bReturn = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect,
		pParentWnd, nID, pContext);

	SetWindowText(m_defaultText);

	//Set a limit to the amount of text that the user can enter. We want this limit
	//to be one less than the space allocated in the file record for the quote string
	//so that the string will be null terminated (399 = sizeof(DOC_RECORD.quote) - 1):
	GetEditCtrl().SetLimitText(399); 

	return bReturn; 
}
/////////////////////////////////////////////////////////////////////////////
BOOL CMyEditView::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= ES_MULTILINE|ES_AUTOVSCROLL;
	
	return CEditView::PreCreateWindow(cs);
}
/////////////////////////////////////////////////////////////////////////////
BOOL CMyEditView::OnEraseBkgnd(CDC* pDC) 
{
	 CEditView::OnEraseBkgnd(pDC);

	 //save old brush when select in new brush:
     CBrush* pOldBrush = pDC->SelectObject(&m_brViewBkgnd);    

	 CRect rect;
	 GetClientRect(&rect);
     pDC->PatBlt(rect.left, rect.top, rect.Width(), rect.Height(), PATCOPY);

	 //return old brush:
     pDC->SelectObject(pOldBrush); 
	
	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
HBRUSH CMyEditView::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	pDC->SetTextColor(m_clrText);   // text color
	pDC->SetBkColor(m_clrCtlBkgnd); // text background
	return m_brCtlBkgnd;            // control background
}
/////////////////////////////////////////////////////////////////////////////
void CMyEditView::OnInitialUpdate() 
{
	//Because of the structure of this app, this function can be called more than once. 
	//The following flag insures the code after it is only run once:
	if(m_bInitialized)
		return;
	m_bInitialized = true;

	CEditView::OnInitialUpdate();
	
	((CMainFrame*)AfxGetMainWnd())->m_pEditView = this;		
}
