//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SDIViewSwitch.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FORMVIEW1                   101
#define IDD_FORMVIEW2                   102
#define IDD_FORMVIEW3                   103
#define IDR_MAINFRAME                   128
#define IDR_SDIVIETYPE                  129
#define NO_FORMVIEW_IN_RIGHT_PANE_HORIZ_SPLITTER_VIEW 136
#define RIGHT_PANE_HORIZ_SPLITTER_VIEW  137
#define IDB_BITMAP1                     138
#define IDI_ICON1                       142
#define IDI_ICON2                       143
#define IDI_ICON3                       144
#define IDI_ICON4                       145
#define IDI_ICON5                       146
#define IDI_ICON6                       147
#define IDI_ICON7                       148
#define IDI_ICON8                       149
#define IDI_ICON9                       150
#define IDI_ICON10                      151
#define IDI_ICON11                      152
#define IDI_ICON12                      153
#define IDI_ICON13                      154
#define IDI_ICON14                      155
#define IDI_ICON15                      156
#define IDI_ICON16                      157
#define IDI_ICON17                      158
#define IDI_ICON18                      159
#define IDI_ICON19                      160
#define IDI_ICON20                      161
#define IDI_ICON21                      162
#define IDI_ICON22                      163
#define IDI_ICON23                      164
#define IDB_HOT                         165
#define IDB_NORMAL                      166
#define IDB_DISABLE                     167
#define IDB_TOP                         168
#define IDB_MIN_NORMAL                  170
#define IDB_CLOSE_NORMAL                171
#define IDB_MAX_NORMAL                  172
#define IDB_RESTORE_NORMAL              173
#define IDB_MEUNBK                      176
#define IDC_RADIO1                      1000
#define IDC_BUTTON1                     1001
#define IDC_CHECK1                      1002
#define IDC_RADIO2                      1002
#define IDC_SLIDER1                     1003
#define IDC_SPIN1                       1004
#define IDC_EDIT1                       1008
#define IDC_EDIT_NAME                   1008
#define IDC_EDIT_ADDRESS                1009
#define IDC_EDIT_CITY                   1010
#define IDC_EDIT_STATE                  1011
#define IDC_EDIT_ZIPCODE                1012
#define IDC_BUT_SUBMIT                  1013
#define IDC_EDIT2                       1014
#define IDC_COMBO1                      1015
#define IDC_SCROLLBAR1                  1016
#define IDC_SCROLLBAR2                  1017
#define ID_VIEW_FORMVIEW1               32771
#define ID_VIEW_FORMVIEW2               32772
#define ID_VIEW_EDITVIEW                32773
#define ID_VIEW_LISTVIEW                32774
#define ID_VIEW_SPLITTER                32775
#define ID_BUSY                         32775
#define ID_ADD_FORM_VIEW                32776
#define ID_FREE                         32776
#define ID_REMOVE_FORM_VIEW             32777
#define ID_TURN                         32780
#define ID_WIMP                         32781
#define IDM_MICROSOFT_HOME              32782
#define ID_MICROSOFT_HOME               32783
#define ID_HUCHU                        32783
#define ID_ZIXUN                        32784
#define ID_DDDD                         32785
#define ID_CHANPIN                      32793
#define ID_ZHISHI                       32799
#define ID_DUANXIN                      32801
#define ID_CHUANZHEN                    32802
#define ID_SHUAXIN                      32829
#define ID_OFFTEL                       32830
#define ID_MAINSKI                      32831
#define ID_STATIC1                      32832
#define IDS_NEW_SWITCH_SPLIT_FILE       61204
#define IDS_CANNOT_CREATE_NEW_SWITCHSPLIT 61205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        177
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
