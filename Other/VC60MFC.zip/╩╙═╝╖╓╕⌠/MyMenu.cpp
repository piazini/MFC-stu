// MyMenu.cpp: implementation of the CMyMenu class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "sdiviewswitch.h"
#include "MyMenu.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyMenu::CMyMenu()
{

}

CMyMenu::~CMyMenu()
{

}
void CMyMenu::AttachMenu(HMENU hMenu)
{
	Attach(hMenu);
	ChangeMenuStyle(hMenu);
}
void CMyMenu::ChangeMenuStyle(HMENU hMenu)
{
	CMenu *pMenu=CMenu::FromHandle(hMenu);
	if(pMenu)
	{
		for(int iCount=0;iCount < pMenu->GetMenuItemCount();iCount++)
		{
			CMenuItemContext *pMenuItem=new CMenuItemContext;
			pMenuItem->nMenuID=pMenu->GetMenuItemID(iCount); //��Ϊֻ��Ҫ���˵��ı�����ɫ������ֻ���ȡ�˵���һ�����ID������...
			pMenu->GetMenuString(iCount,pMenuItem->lpszText,MF_BYPOSITION);
			pMenu->ModifyMenu(iCount,MF_OWNERDRAW | MF_BYPOSITION,pMenuItem->nMenuID,LPCTSTR(pMenuItem));
		}
	}
}
void CMyMenu::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	CDC *pDC=CDC::FromHandle(lpDrawItemStruct->hDC);
	CString strText=((CMenuItemContext *)lpDrawItemStruct->itemData)->lpszText;
	CRect rcItem=lpDrawItemStruct->rcItem;
	CRect rcMain(rcItem);
	rcMain.left=rcItem.Width()*4;
	rcMain.right=rcMain.left+400;
	SetBKColor(pDC,rcItem);
	rcItem.top+=5;
	pDC->SetBkMode(TRANSPARENT);
	pDC->DrawText(strText,rcItem,DT_CENTER);
	SetBKColor(pDC,rcMain);
}
void CMyMenu::SetBKColor(CDC *pDC,CRect rcItem)
{
	CBitmap* pBitmap = new CBitmap;
	BITMAP BmpInfo;
	CBitmap* pOldBitmap;
	CDC* pDisplayMemDC=new CDC;
	pDisplayMemDC->CreateCompatibleDC(pDC);
	pBitmap->LoadBitmap(IDB_TOP);
	pOldBitmap=(CBitmap*)pDisplayMemDC->SelectObject(pBitmap);
	pBitmap->GetBitmap(&BmpInfo);
	CPoint DrawPonit;
	DrawPonit.x=rcItem.left;
	while(DrawPonit.x<= rcItem.right+1) 
	{
		pDC->BitBlt(DrawPonit.x, rcItem.top, BmpInfo.bmWidth, rcItem.Height(), pDisplayMemDC, 0, 0, SRCCOPY);
		DrawPonit.x = DrawPonit.x + BmpInfo.bmWidth;
	}
	pBitmap->DeleteObject();}
void CMyMenu::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	
	lpMeasureItemStruct->itemWidth=30;
}
