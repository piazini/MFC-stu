#if !defined(AFX_FORMVIEW3_H__CB97F4D2_1752_11D2_B134_00C04FB9CA2B__INCLUDED_)
#define AFX_FORMVIEW3_H__CB97F4D2_1752_11D2_B134_00C04FB9CA2B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// FormView3.h : header file
//
#include "ColorFormView.h"

/////////////////////////////////////////////////////////////////////////////
// CFormView3 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CFormView3 : public CColorFormView
{
protected:
	CFormView3();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFormView3)

// Form Data
public:
	//{{AFX_DATA(CFormView3)
	enum { IDD = IDD_FORMVIEW3 };
	CString	m_strAddress;
	CString	m_strCity;
	CString	m_strName;
	CString	m_strState;
	CString	m_strZipCode;
	//}}AFX_DATA

// Attributes
public:
    CBrush* m_pEditBkBrush;
	COLORREF m_crGreen;

// Operations
public:
	void AddItemToListView(UINT nRecordIndex);
	void ClearForm();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFormView3)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFormView3();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CFormView3)
	afx_msg void OnSubmitData();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORMVIEW3_H__CB97F4D2_1752_11D2_B134_00C04FB9CA2B__INCLUDED_)
